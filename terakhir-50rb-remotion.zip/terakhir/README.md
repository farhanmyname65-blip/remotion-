# TERAKHIR - 50RB TERAKHIR (Remotion, 1080x1920, 60 dtk, 30fps)

    npm install
    npm start          # preview di Remotion Studio
    npm run render     # hasil: out/terakhir-50rb.mp4

- Backsound sintetis ada di public/backsound.wav (bisa dibuat ulang: npm run backsound).
- Voice over: rekam/TTS per baris, taruh di public/vo/ (nama file ada di src/Video.tsx), lalu set VO_READY = true.
- Subtitle ada di array SUBS (src/Video.tsx).
