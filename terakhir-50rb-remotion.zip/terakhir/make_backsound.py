# Backsound 60 dtk: jam tik-tok, jangkrik, drone 60Hz, detak jantung, pad hangat + azan jauh (sintetis)
import numpy as np, wave
SR = 22050; T = 60
t = np.arange(SR * T) / SR
def win(a, b, fade=0.5):
    return np.clip((t - a) / fade, 0, 1) * np.clip((b - t) / fade, 0, 1)
out = np.zeros_like(t)
drone = (np.sin(2*np.pi*60*t) + 0.4*np.sin(2*np.pi*120*t)) * 0.22
out += drone * (win(0, 10) + win(20, 50, 1.5))
tick = np.zeros_like(t)
for s in range(T):
    for off, fr, amp in ((0, 1800, 0.5), (0.5, 1200, 0.4)):
        i = int((s + off) * SR); n = int(0.05 * SR)
        if i + n < len(t):
            k = np.arange(n) / SR
            tick[i:i+n] += np.sin(2*np.pi*fr*k) * np.exp(-k*90) * amp
out += tick * (0.5 + 0.5*win(0, 60, 0.1)) * np.where((t > 10) & (t < 20), 0.15, 1)
cr = np.zeros_like(t)
for k in range(3):
    cr += np.sin(2*np.pi*4300*t) * (np.sin(2*np.pi*(18)*(t - k*0.09)) > 0.6) * (((t*0.8) % 1.0) < 0.35)
out += cr * 0.04 * (win(0, 10) + win(30, 50, 1.5))
hb = np.zeros_like(t)
for s in np.arange(25, 27.4, 0.9):
    for off, amp in ((0, 0.9), (0.25, 0.6)):
        i = int((s + off) * SR); n = int(0.18 * SR); k = np.arange(n) / SR
        hb[i:i+n] += np.sin(2*np.pi*55*k) * np.exp(-k*22) * amp
out += hb * 0.9
pad = sum(np.sin(2*np.pi*f*t) for f in (220, 277.2, 329.6)) * 0.05
out += pad * win(50, 60, 4)
az = np.sin(2*np.pi*(440 + 40*np.sin(2*np.pi*0.35*t))*t) * 0.02
out += az * win(52, 60, 2)
out /= max(1.0, np.abs(out).max() / 0.9)
with wave.open('public/backsound.wav', 'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((out * 32767).astype(np.int16).tobytes())
print('ok')
