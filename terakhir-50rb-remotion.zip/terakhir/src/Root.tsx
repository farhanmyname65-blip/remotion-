import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {FPS, H, W} from './common';

export const Root: React.FC = () => (
  <Composition id="Terakhir" component={Video} durationInFrames={FPS * 60} fps={FPS} width={W} height={H} />
);
