import React from 'react';
import {AbsoluteFill, Easing, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Clock, FONT, H, Handheld, KosRoom, Kinetic, Particles, Phone, W, clamp, rp} from './common';
import {Dani, Ibu, Riko} from './characters';

/* ===== SCENE 1 — KOS BERANTAKAN / JUDOL ===== */
export const Scene1: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const push = interpolate(f, [0, 300], [1, 1.28], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const phoneIn = spring({frame: f - 110, fps, config: {damping: 16}});
  const items = [['JUDOL KALAH', '-Rp 500.000'], ['JUDOL KALAH', '-Rp 300.000'], ['JUDOL KALAH', '-Rp 1.000.000'], ['TOP UP SLOT', '-Rp 200.000']];
  const glitch = f % 41 < 3;
  return (
    <AbsoluteFill>
      <Handheld amount={5}>
        <AbsoluteFill style={{transform: `scale(${push})`, transformOrigin: '50% 60%'}}>
          <KosRoom bright={0.1} />
          <div style={{position: 'absolute', left: 260, top: 760}}><Riko expr={f < 150 ? 'tired' : 'cry'} scale={1.4} /></div>
          <div style={{position: 'absolute', left: 140, top: 780, width: 800, height: 800, mixBlendMode: 'screen',
            background: `radial-gradient(circle, rgba(130,190,255,${0.5 + 0.1 * Math.sin(f * 0.3)}), transparent 65%)`}} />
          <div style={{position: 'absolute', left: 450, top: 1190, width: 180, height: 300, borderRadius: 24, transform: 'rotate(-6deg)',
            background: 'linear-gradient(#cfe8ff,#6fb2ff)', boxShadow: '0 0 120px 50px rgba(120,190,255,.6)'}} />
          <Particles count={30} color="180,220,255" speed={0.6} seed="s1" size={5} />
        </AbsoluteFill>
        <div style={{position: 'absolute', left: 280, top: 400, transform: `translateY(${(1 - phoneIn) * 1300}px)`}}>
          <Phone w={520} h={980}>
            <div style={{padding: '60px 36px', fontFamily: FONT, color: '#fff'}}>
              <div style={{fontSize: 30, opacity: 0.6}}>E-WALLET</div>
              <div style={{fontSize: 34, marginTop: 30, opacity: 0.8}}>SALDO</div>
              <div style={{fontSize: 108, color: '#ff4d5e', transform: glitch ? 'translateX(8px)' : undefined, textShadow: glitch ? '-8px 0 #00e5ff' : '0 0 30px rgba(255,60,80,.6)'}}>Rp 0</div>
              <div style={{marginTop: 50, fontSize: 28, opacity: 0.6}}>RIWAYAT</div>
              {items.map(([a, b], i) => {
                const p = spring({frame: f - 135 - i * 10, fps, config: {damping: 14}});
                return (
                  <div key={i} style={{marginTop: 18, padding: '18px 20px', borderRadius: 18, background: 'rgba(255,60,80,.14)', border: '2px solid rgba(255,60,80,.5)',
                    opacity: p, transform: `translateX(${(1 - p) * 120}px)`, display: 'flex', justifyContent: 'space-between', fontSize: 26}}>
                    <span style={{color: '#ff8a96'}}>{a}</span><span>{b}</span>
                  </div>
                );
              })}
            </div>
          </Phone>
        </div>
      </Handheld>
      <Kinetic text="Bekal 1 bulan, habis 2 hari." delay={20} size={84} top={130} />
    </AbsoluteFill>
  );
};

/* ===== SCENE 2 — BOHONG KE IBU (split screen, POV HP) ===== */
export const Scene2: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const bub = spring({frame: f - 40, fps, config: {damping: 12}});
  const bubOut = interpolate(f, [100, 118], [1, 0], clamp);
  const fire = 0.7 + 0.3 * Math.sin(f * 0.7);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Handheld amount={16}>
        <div style={{position: 'absolute', left: 0, top: 0, width: 538, height: H, overflow: 'hidden',
          background: 'repeating-linear-gradient(90deg,#6b4a2a 0 60px,#5a3d22 60px 64px)'}}>
          <div style={{position: 'absolute', left: 60, top: 1050, width: 420, height: 300, background: '#2a1d12', borderRadius: 20}} />
          <div style={{position: 'absolute', left: 190, top: 960, width: 160, height: 160, borderRadius: '50%', background: `radial-gradient(#ffd27a,#ff7a1a 55%,transparent 72%)`, opacity: fire, filter: 'blur(4px)'}} />
          <Particles count={18} color="255,210,150" speed={1.6} seed="steam" size={9} />
          <div style={{position: 'absolute', left: -20, top: 520}}><Ibu mood={f < 150 ? 'worry' : 'cry'} scale={1.5} /></div>
          <div style={{position: 'absolute', left: 120, top: 380, padding: '20px 30px', borderRadius: 30, background: '#fff', fontFamily: FONT, fontSize: 44,
            color: '#222', opacity: bub * bubOut, transform: `scale(${0.6 + 0.4 * bub})`}}>Cukup nak?</div>
        </div>
        <div style={{position: 'absolute', left: 542, top: 0, width: 538, height: H, overflow: 'hidden', background: 'linear-gradient(#4a4128,#1c170c)'}}>
          <div style={{position: 'absolute', left: -30, top: 520}}><Riko expr={f < 110 ? 'tired' : 'fake'} scale={1.5} /></div>
          <div style={{position: 'absolute', inset: 0, background: 'rgba(255,150,200,.14)', mixBlendMode: 'screen'}} />
          <Particles count={26} color="255,190,230" speed={0.8} seed="filter" size={10} />
          <div style={{position: 'absolute', left: 20, top: 1500, width: 500, height: 20, background: '#6b4f33', borderRadius: 10}} />
          <div style={{position: 'absolute', left: 90, top: 1410, width: 150, height: 90, borderRadius: 24, background: '#e7c14a', border: '6px solid #b78f2b'}} />
          <div style={{position: 'absolute', left: 260, top: 1410, width: 150, height: 90, borderRadius: 24, background: '#e7c14a', border: '6px solid #b78f2b'}} />
          <div style={{position: 'absolute', left: 60, top: 1530, width: 420, textAlign: 'center', fontFamily: FONT, fontSize: 26, color: '#ffd24a'}}>MIE 1 BUNGKUS, DIBAGI 2</div>
        </div>
        <div style={{position: 'absolute', left: 536, top: 0, width: 8, height: H, background: '#fff', boxShadow: '0 0 40px 10px rgba(255,255,255,.7)'}} />
        <div style={{position: 'absolute', left: 40, top: 60, fontFamily: FONT, color: '#fff', fontSize: 30, opacity: 0.9}}>● VIDEO CALL  02:{String(14 + Math.floor(f / 30)).padStart(2, '0')}</div>
      </Handheld>
      <Kinetic text="Cukup Bu, enak terus kok..." delay={120} size={72} top={170} />
    </AbsoluteFill>
  );
};

/* ===== SCENE 3 — TELPON BAPAK + CELENGAN 50RB ===== */
export const Scene3: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const SMASH = 192;
  const swing = interpolate(f, [150, 185, 192, 205], [-70, -95, 20, 5], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const zoom = interpolate(f, [200, 300], [1, 1.25], clamp);
  const count = interpolate(f, [235, 290], [0, 50000], {...clamp, easing: Easing.out(Easing.cubic)});
  const beat = f > 150 && f < 215 ? Math.max(0, Math.sin(((f - 150) / 30) * Math.PI * 2 * 1.1)) ** 6 : 0;
  const coinVals = [500, 1000, 500];
  return (
    <AbsoluteFill style={{background: '#07070a'}}>
      {f < 150 && (
        <AbsoluteFill>
          <Kinetic text="JANUARI 2027" delay={0} size={58} color="#ffd24a" top={110} />
          <div style={{position: 'absolute', left: 260, top: 260, transform: `translateX(${Math.sin(f * 3) * 6}px)`}}>
            <Phone w={560} h={720}>
              <div style={{height: '100%', background: 'linear-gradient(#1a2433,#0b0f17)', textAlign: 'center', fontFamily: FONT, color: '#fff', paddingTop: 70}}>
                <div style={{position: 'relative', width: 200, height: 200, margin: '0 auto'}}>
                  {[0, 1, 2].map((i) => {
                    const t = ((f + i * 14) % 42) / 42;
                    return <div key={i} style={{position: 'absolute', inset: 0, borderRadius: '50%', border: '4px solid #4cd964', opacity: 1 - t, transform: `scale(${1 + t * 1.2})`}} />;
                  })}
                  <div style={{position: 'absolute', inset: 20, borderRadius: '50%', background: '#52627a', fontSize: 90, lineHeight: '160px'}}>👤</div>
                </div>
                <div style={{fontSize: 56, marginTop: 50}}>BAPAK</div>
                <div style={{fontSize: 40, color: '#4cd964', marginTop: 10}}>NELPON...</div>
                <div style={{display: 'flex', justifyContent: 'space-around', marginTop: 90}}>
                  <div style={{width: 110, height: 110, borderRadius: '50%', background: '#ff3b30'}} />
                  <div style={{width: 110, height: 110, borderRadius: '50%', background: '#4cd964'}} />
                </div>
              </div>
            </Phone>
          </div>
          <div style={{position: 'absolute', left: 240, top: 1000}}><Riko expr={f < 60 ? 'shock' : 'cry'} scale={1.5} /></div>
        </AbsoluteFill>
      )}
      {f >= 150 && (
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 55%,#4a3220,#140d07 75%)'}}>
          <AbsoluteFill style={{transform: `scale(${zoom})`, transformOrigin: '50% 60%'}}>
            {f < SMASH + 4 && (
              <div style={{position: 'absolute', left: 340, top: 760, width: 400, height: 300}}>
                <div style={{position: 'absolute', inset: '40px 0 0 0', borderRadius: '50%', background: '#c0623a'}} />
                <div style={{position: 'absolute', left: 150, top: 10, width: 80, height: 70, borderRadius: '40px 40px 0 0', background: '#a94d2b'}} />
                <div style={{position: 'absolute', left: 300, top: 120, width: 100, height: 70, borderRadius: 30, background: '#d97b50'}} />
                <div style={{position: 'absolute', left: 140, top: 56, width: 120, height: 10, borderRadius: 5, background: '#2a140a'}} />
              </div>
            )}
            {f >= SMASH && [0, 1, 2, 3, 4, 5, 6, 7].map((i) => {
              const t = f - SMASH;
              const a = (i / 8) * Math.PI * 2;
              const d = Math.min(1, t / 25) * (240 + random(`sh${i}`) * 220);
              return <div key={i} style={{position: 'absolute', left: 540 + Math.cos(a) * d, top: 900 + Math.sin(a) * d * 0.8, width: 80, height: 60,
                background: '#b4532f', clipPath: 'polygon(0 0,100% 20%,60% 100%)', opacity: 1 - t / 120, transform: `rotate(${i * 40 + t * 5}deg)`}} />;
            })}
            <div style={{transform: `translate(${Math.sin(f * 2.1) * 3}px,${Math.cos(f * 2.7) * 3}px)`}}>
              {new Array(26).fill(0).map((_, i) => {
                const t = f - (SMASH + 6 + i * 2);
                if (t < 0) return null;
                const p = spring({frame: t, fps, config: {damping: 9, stiffness: 120}});
                const fx = 540 + (random(`cx${i}`) * 2 - 1) * 320, fy = 1050 + random(`cy${i}`) * 360;
                const v = coinVals[i % 3];
                return (
                  <div key={i} style={{position: 'absolute', left: 540 + (fx - 540) * p - 46, top: 880 + (fy - 880) * p - 46, width: 92, height: 92, borderRadius: '50%',
                    background: 'radial-gradient(circle at 35% 30%,#fff1a8,#d4a72c 60%,#8a6a14)', border: '6px solid #a37d1b', boxShadow: '0 10px 20px rgba(0,0,0,.5)',
                    fontFamily: FONT, fontSize: 28, color: '#5b4208', textAlign: 'center', lineHeight: '80px', transform: `rotate(${random(`cr${i}`) * 360}deg)`}}>
                    <span style={{display: 'inline-block', transform: `rotate(${-random(`cr${i}`) * 360}deg)`}}>{v}</span>
                  </div>
                );
              })}
            </div>
          </AbsoluteFill>
          <div style={{position: 'absolute', left: 540 - 220, top: 560, width: 440, height: 80, transformOrigin: '92% 90%', transform: `rotate(${swing}deg)`, opacity: f < 240 ? 1 : 0}}>
            <div style={{position: 'absolute', right: 0, top: 20, width: 340, height: 24, background: '#7a5230', borderRadius: 12}} />
            <div style={{position: 'absolute', left: 0, top: 0, width: 130, height: 80, background: '#8a8d93', borderRadius: 10}} />
          </div>
          <AbsoluteFill style={{background: 'radial-gradient(ellipse at center,transparent 35%,rgba(180,0,0,.8))', opacity: beat * 0.8}} />
          {f > 210 && <Kinetic text="SISA TERAKHIR:" delay={215} size={70} color="#fff" top={170} />}
          {f > 225 && <div style={{position: 'absolute', left: 0, right: 0, top: 330, textAlign: 'center', fontFamily: FONT, fontSize: 130, color: '#ffd24a',
            textShadow: '0 0 40px rgba(255,200,60,.7)', transform: `scale(${1 + 0.04 * Math.sin(f * 0.5)})`}}>{rp(count)}</div>}
        </AbsoluteFill>
      )}
    </AbsoluteFill>
  );
};
