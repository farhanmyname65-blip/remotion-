import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';

export const W = 1080, H = 1920, FPS = 30;
export const FONT = "'Arial Black','Montserrat',Impact,system-ui,sans-serif";
export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
export const rp = (n: number) => 'Rp ' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');

/* ---------- kamera handheld gemeter ---------- */
export const Handheld: React.FC<{amount?: number; children?: React.ReactNode}> = ({amount = 6, children}) => {
  const f = useCurrentFrame();
  const x = (Math.sin(f * 0.13) + Math.sin(f * 0.31 + 2) * 0.6) * amount;
  const y = (Math.cos(f * 0.11) + Math.sin(f * 0.27 + 1) * 0.6) * amount;
  const r = Math.sin(f * 0.07) * 0.35 * (amount / 6);
  return (
    <AbsoluteFill style={{transform: `translate(${x}px,${y}px) rotate(${r}deg) scale(1.05)`}}>{children}</AbsoluteFill>
  );
};

/* ---------- partikel ---------- */
export const Particles: React.FC<{count?: number; color?: string; speed?: number; seed?: string; size?: number}> = ({
  count = 40, color = '255,220,120', speed = 1.2, seed = 'p', size = 6,
}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {new Array(count).fill(0).map((_, i) => {
        const r1 = random(`${seed}a${i}`), r2 = random(`${seed}b${i}`), r3 = random(`${seed}c${i}`);
        const x = r1 * W + Math.sin(f * 0.02 + i) * 30;
        const y = (((r2 * H - f * speed * (0.4 + r3)) % H) + H) % H;
        const s = size * (0.4 + r3 * 1.2);
        const o = 0.15 + 0.5 * Math.abs(Math.sin(f * 0.05 + i * 1.3));
        return (
          <div key={i} style={{position: 'absolute', left: x, top: y, width: s, height: s, borderRadius: '50%',
            background: `rgba(${color},${o})`, boxShadow: `0 0 ${s * 3}px rgba(${color},${o})`}} />
        );
      })}
    </AbsoluteFill>
  );
};

/* ---------- teks kinetik: per huruf, blur -> sharp, glitch RGB ---------- */
export const Kinetic: React.FC<{text: string; delay?: number; size?: number; color?: string; top?: number; stagger?: number; glitch?: boolean}> = ({
  text, delay = 0, size = 84, color = '#fff', top = 240, stagger = 2, glitch = true,
}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const g = glitch && f % 53 < 3 && f > delay + 30;
  let idx = 0;
  return (
    <div style={{position: 'absolute', left: 50, right: 50, top, textAlign: 'center', fontFamily: FONT, fontWeight: 900,
      fontSize: size, color, lineHeight: 1.1,
      textShadow: g ? '7px 0 #ff2d55,-7px 0 #00e5ff' : '0 6px 28px rgba(0,0,0,.8)',
      transform: g ? `translateX(${f % 2 ? 9 : -9}px)` : undefined}}>
      {text.split(' ').map((w, wi) => (
        <span key={wi} style={{display: 'inline-block', marginRight: size * 0.28, whiteSpace: 'nowrap'}}>
          {w.split('').map((c, ci) => {
            const k = idx++;
            const p = spring({frame: f - delay - k * stagger, fps, config: {damping: 11, stiffness: 140}});
            return (
              <span key={ci} style={{display: 'inline-block', opacity: p > 0.02 ? Math.min(1, p * 1.5) : 0,
                transform: `translateY(${(1 - p) * 70}px) scale(${0.6 + 0.4 * p}) rotate(${(1 - p) * (k % 2 ? 12 : -12)}deg)`,
                filter: `blur(${Math.max(0, 1 - p) * 8}px)`}}>{c}</span>
            );
          })}
        </span>
      ))}
    </div>
  );
};

/* ---------- subtitle burn-in: putih bold, stroke hitam, di bawah ---------- */
export type Sub = {from: number; to: number; text: string};
export const Subtitles: React.FC<{subs: Sub[]}> = ({subs}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cur = subs.find((s) => f >= s.from * fps && f < s.to * fps);
  if (!cur) return null;
  const local = f - cur.from * fps;
  return (
    <div style={{position: 'absolute', left: 50, right: 50, bottom: 250, textAlign: 'center', fontFamily: FONT, fontWeight: 900,
      fontSize: 62, lineHeight: 1.2, color: '#fff', WebkitTextStroke: '12px #000', paintOrder: 'stroke fill'}}>
      {cur.text.split(' ').map((w, i) => {
        const p = spring({frame: local - i * 3, fps, config: {damping: 14, stiffness: 200}});
        return (
          <span key={i} style={{display: 'inline-block', marginRight: 16, opacity: Math.min(1, p * 2),
            transform: `scale(${0.7 + 0.3 * p}) translateY(${(1 - p) * 20}px)`}}>{w}</span>
        );
      })}
    </div>
  );
};

/* ---------- grain film + vignette ---------- */
export const FilmOverlay: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <svg width={W} height={H} style={{position: 'absolute', mixBlendMode: 'overlay', opacity: 0.35}}>
        <filter id="grain"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves={2} seed={f % 40} stitchTiles="stitch" /></filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 45%, rgba(0,0,0,.65) 100%)'}} />
    </AbsoluteFill>
  );
};

/* ---------- jam dinding tik-tok ---------- */
export const Clock: React.FC<{x: number; y: number; fast?: number}> = ({x, y, fast = 0}) => {
  const f = useCurrentFrame();
  const sec = fast ? f * fast : Math.floor(f / 30) * 6;
  return (
    <div style={{position: 'absolute', left: x - 70, top: y - 70, width: 140, height: 140, borderRadius: '50%', background: '#e9e2cf',
      border: '8px solid #3a2c1a', boxShadow: '0 8px 30px rgba(0,0,0,.6)'}}>
      <div style={{position: 'absolute', left: 62, top: 62, width: 8, height: 8, borderRadius: 4, background: '#111'}} />
      <div style={{position: 'absolute', left: 64, top: 24, width: 5, height: 44, background: '#111', transformOrigin: '50% 40px', transform: `rotate(${sec / 12 + 90}deg)`}} />
      <div style={{position: 'absolute', left: 65, top: 10, width: 3, height: 58, background: '#c0392b', transformOrigin: '50% 54px', transform: `rotate(${sec}deg)`}} />
    </div>
  );
};

/* ---------- kamar kos 3x3 ---------- */
export const KosRoom: React.FC<{tidy?: boolean; bright?: number; clockFast?: number}> = ({tidy = false, bright = 0.5, clockFast = 0}) => {
  const f = useCurrentFrame();
  const flick = 0.88 + 0.12 * Math.sin(f * 0.9) * Math.sin(f * 0.13);
  const clothes = [[60, 1500, -12, '#6d3b3b'], [300, 1560, 8, '#3b5a6d'], [640, 1520, -5, '#5d6d3b'], [820, 1600, 15, '#6d5b3b'], [140, 1700, 4, '#4a3b6d']];
  const cups = [[430, 1640], [720, 1720], [210, 1560]];
  return (
    <AbsoluteFill style={{background: 'linear-gradient(#3d3520 0%,#221d11 62%,#17130b 62%,#0e0b07 100%)', filter: `brightness(${bright * flick + 0.3})`}}>
      <div style={{position: 'absolute', top: 120, left: 240, width: 600, height: 18, borderRadius: 9, background: '#fff3b0', boxShadow: '0 0 90px 36px rgba(255,214,80,.5)', opacity: flick}} />
      <Clock x={900} y={330} fast={clockFast} />
      <div style={{position: 'absolute', left: -60, top: 1160, width: 800, height: 280, borderRadius: 34, background: tidy ? '#4e6f93' : '#5a4838'}} />
      <div style={{position: 'absolute', left: -60, top: 1140, width: 800, height: 90, borderRadius: 34, background: tidy ? '#e8e4d8' : '#7a6650'}} />
      {!tidy && clothes.map(([x, y, r, c], i) => (
        <div key={i} style={{position: 'absolute', left: x as number, top: y as number, width: 220, height: 90, borderRadius: 40, background: c as string, transform: `rotate(${r}deg)`}} />
      ))}
      {!tidy && cups.map(([x, y], i) => (
        <div key={i} style={{position: 'absolute', left: x, top: y, width: 90, height: 70, borderRadius: '10px 10px 24px 24px', background: '#d8b43c', border: '5px solid #b4392b'}} />
      ))}
    </AbsoluteFill>
  );
};

export const Phone: React.FC<{w?: number; h?: number; children?: React.ReactNode; style?: React.CSSProperties}> = ({w = 520, h = 980, children, style}) => (
  <div style={{width: w, height: h, borderRadius: 64, background: '#0b0b12', border: '10px solid #23232b', boxShadow: '0 0 90px rgba(120,180,255,.5)', overflow: 'hidden', position: 'relative', ...style}}>
    {children}
  </div>
);
