import React from 'react';
import {useCurrentFrame} from 'remotion';

export type Expr = 'tired' | 'shock' | 'cry' | 'fake' | 'sweat' | 'happy' | 'focus';

const BROWS: Record<Expr, [string, string]> = {
  tired: ['M148 222 L188 208', 'M212 208 L252 222'],
  cry: ['M148 224 L188 206', 'M212 206 L252 224'],
  sweat: ['M148 222 L188 208', 'M212 208 L252 222'],
  shock: ['M148 196 Q168 182 188 196', 'M212 196 Q232 182 252 196'],
  focus: ['M148 206 L188 220', 'M212 220 L252 206'],
  fake: ['M148 210 Q168 202 188 210', 'M212 210 Q232 202 252 210'],
  happy: ['M148 208 Q168 198 188 208', 'M212 208 Q232 198 252 208'],
};

/* RIKO — satu desain, dipakai di semua scene => muka selalu sama */
export const Riko: React.FC<{expr: Expr; scale?: number; style?: React.CSSProperties}> = ({expr, scale = 1, style}) => {
  const f = useCurrentFrame();
  const blink = f % 100 > 96;
  const br = Math.sin(f * 0.08) * 3;
  const skin = '#c9936a', skinD = '#a8744f', hair = '#14100d';
  const arc = expr === 'fake' || expr === 'happy';
  const ry = blink ? 1 : expr === 'shock' ? 21 : expr === 'tired' || expr === 'cry' ? 9 : expr === 'focus' ? 11 : 15;
  const pr = expr === 'shock' ? 5 : 7;
  const look = expr === 'tired' ? 4 : 0;
  const [bl, bR] = BROWS[expr];
  const tearT = (o: number) => (f * 3 + o) % 70;
  return (
    <svg viewBox="0 0 400 600" width={400 * scale} height={600 * scale} style={style}>
      <g transform={`translate(0 ${br})`}>
        <path d="M60 600 L85 430 Q110 385 165 372 L235 372 Q290 385 315 430 L340 600Z" fill="#101010" />
        <path d="M70 560 Q130 540 140 600 M300 540 Q330 560 335 600" stroke="#1c1c1c" strokeWidth="6" fill="none" />
        <rect x="172" y="330" width="56" height="50" fill={skinD} />
        <path d="M165 372 Q200 412 235 372Z" fill={skinD} />
        <ellipse cx="120" cy="262" rx="14" ry="24" fill={skin} />
        <ellipse cx="280" cy="262" rx="14" ry="24" fill={skin} />
        <ellipse cx="200" cy="250" rx="80" ry="98" fill={skin} />
        <path d="M118 238 Q112 150 175 140 Q205 120 240 140 Q292 150 284 238 Q268 190 250 186 L238 172 L214 196 L190 168 L168 196 L146 186 Q128 200 118 238Z" fill={hair} />
        <path d="M150 150 L124 116 L176 142Z" fill={hair} />
        <path d="M250 146 L284 120 L264 162Z" fill={hair} />
        <path d="M205 132 L216 98 L234 138Z" fill={hair} />
        <path d="M142 274 Q168 290 192 274" stroke="#6b4630" strokeWidth="5" fill="none" opacity=".65" />
        <path d="M208 274 Q232 290 258 274" stroke="#6b4630" strokeWidth="5" fill="none" opacity=".65" />
        {arc ? (
          <g stroke="#1a1109" strokeWidth="7" fill="none" strokeLinecap="round">
            <path d="M146 254 Q168 230 190 254" />
            <path d="M210 254 Q232 230 254 254" />
          </g>
        ) : (
          <g>
            <ellipse cx="168" cy="252" rx="21" ry={ry} fill="#fff" stroke="#3a2418" strokeWidth="3" />
            <ellipse cx="232" cy="252" rx="21" ry={ry} fill="#fff" stroke="#3a2418" strokeWidth="3" />
            {!blink && <circle cx="168" cy={252 + look} r={pr} fill="#1a1109" />}
            {!blink && <circle cx="232" cy={252 + look} r={pr} fill="#1a1109" />}
          </g>
        )}
        <g stroke="#14100d" strokeWidth="8" strokeLinecap="round" fill="none">
          <path d={bl} />
          <path d={bR} />
        </g>
        <path d="M200 262 Q192 292 204 296" stroke={skinD} strokeWidth="5" fill="none" strokeLinecap="round" />
        {expr === 'tired' && <path d="M178 320 Q200 308 222 320" stroke="#5a2e22" strokeWidth="6" fill="none" strokeLinecap="round" />}
        {expr === 'focus' && <path d="M180 318 L220 318" stroke="#5a2e22" strokeWidth="6" strokeLinecap="round" />}
        {expr === 'shock' && <ellipse cx="200" cy="322" rx="16" ry="22" fill="#3a1410" />}
        {expr === 'cry' && <path d="M172 330 Q200 304 228 330" stroke="#5a2e22" strokeWidth="6" fill="none" strokeLinecap="round" />}
        {expr === 'sweat' && <path d="M176 318 q8 -8 16 0 t16 0 t16 0" stroke="#5a2e22" strokeWidth="5" fill="none" strokeLinecap="round" />}
        {(expr === 'fake' || expr === 'happy') && (
          <g>
            <path d="M158 298 Q200 348 242 298Z" fill="#3a1410" />
            <path d="M168 301 Q200 316 232 301 L232 299 L168 299Z" fill="#fff" />
          </g>
        )}
        {expr === 'happy' && <g fill="#e07a5f" opacity=".45"><circle cx="148" cy="290" r="16" /><circle cx="252" cy="290" r="16" /></g>}
        {expr === 'cry' && [150, 250].map((x, i) => (
          <circle key={i} cx={x + (i ? 4 : -4)} cy={266 + tearT(i * 25)} r="6" fill="#8fd3ff" opacity={1 - tearT(i * 25) / 70} />
        ))}
        {(expr === 'sweat' || expr === 'focus') && [0, 35].map((o, i) => (
          <path key={i} d={`M${262 - i * 4} ${180 + ((f * 2 + o) % 60)} q-8 14 0 20 q8 -6 0 -20Z`} fill="#bfe9ff" opacity={0.9 - ((f * 2 + o) % 60) / 80} />
        ))}
      </g>
    </svg>
  );
};

/* IBU di kampung (kerudung) */
export const Ibu: React.FC<{mood: 'worry' | 'cry' | 'joy'; scale?: number}> = ({mood, scale = 1}) => {
  const f = useCurrentFrame();
  const br = Math.sin(f * 0.07) * 2;
  const skin = '#d9a77c';
  return (
    <svg viewBox="0 0 400 600" width={400 * scale} height={600 * scale}>
      <g transform={`translate(0 ${br})`}>
        <path d="M40 600 L70 440 Q110 395 200 390 Q290 395 330 440 L360 600Z" fill="#8a5a7a" />
        {[0, 1, 2, 3, 4, 5].map((i) => <circle key={i} cx={90 + i * 45} cy={470 + (i % 2) * 50} r="9" fill="#e8c9d8" opacity=".6" />)}
        <path d="M70 340 Q56 110 200 92 Q344 110 330 340 Q316 440 200 446 Q84 440 70 340Z" fill="#6b2a3a" />
        <ellipse cx="200" cy="262" rx="64" ry="80" fill={skin} />
        <g stroke="#3a2418" strokeWidth="6" strokeLinecap="round" fill="none">
          {mood === 'joy' ? (<><path d="M152 262 Q172 240 192 262" /><path d="M208 262 Q228 240 248 262" /></>) : (<><ellipse cx="172" cy="260" rx="9" ry={mood === 'cry' ? 6 : 10} fill="#2a1a10" /><ellipse cx="228" cy="260" rx="9" ry={mood === 'cry' ? 6 : 10} fill="#2a1a10" /></>)}
          <path d={mood === 'joy' ? 'M150 232 Q172 222 192 232 M208 232 Q228 222 250 232' : 'M150 240 L192 226 M208 226 L250 240'} />
        </g>
        {mood === 'worry' && <path d="M174 328 Q200 316 226 328" stroke="#6a3b2b" strokeWidth="6" fill="none" strokeLinecap="round" />}
        {mood === 'cry' && <path d="M172 332 Q200 310 228 332" stroke="#6a3b2b" strokeWidth="6" fill="none" strokeLinecap="round" />}
        {mood === 'joy' && <path d="M164 308 Q200 346 236 308Z" fill="#5a1f1a" />}
        {(mood === 'cry' || mood === 'joy') && [152, 248].map((x, i) => {
          const t = (f * 3 + i * 30) % 70;
          return <circle key={i} cx={x} cy={276 + t} r="6" fill="#8fd3ff" opacity={1 - t / 70} />;
        })}
      </g>
    </svg>
  );
};

/* DANI teman kos (topi merah, hoodie biru, bawa gorengan) */
export const Dani: React.FC<{scale?: number}> = ({scale = 1}) => {
  const f = useCurrentFrame();
  const br = Math.sin(f * 0.1) * 3;
  return (
    <svg viewBox="0 0 400 600" width={400 * scale} height={600 * scale}>
      <g transform={`translate(0 ${br})`}>
        <path d="M40 600 L70 430 Q110 385 200 380 Q290 385 330 430 L360 600Z" fill="#3d63a8" />
        <ellipse cx="200" cy="262" rx="84" ry="92" fill="#e0ad82" />
        <path d="M112 230 Q120 140 200 138 Q280 140 288 230 Q200 200 112 230Z" fill="#c0392b" />
        <rect x="200" y="206" width="130" height="26" rx="13" fill="#a93226" />
        <circle cx="166" cy="262" r="9" fill="#2a1a10" /><circle cx="234" cy="262" r="9" fill="#2a1a10" />
        <path d="M160 300 Q200 340 240 300Z" fill="#5a1f1a" />
        <ellipse cx="320" cy="520" rx="90" ry="22" fill="#e8e4d8" />
        {[0, 1, 2, 3].map((i) => <ellipse key={i} cx={270 + i * 32} cy={502 - (i % 2) * 14} rx="26" ry="16" fill="#d9942a" />)}
      </g>
    </svg>
  );
};
