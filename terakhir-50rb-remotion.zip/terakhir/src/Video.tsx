import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {FilmOverlay, Sub, Subtitles, clamp} from './common';
import {Scene1, Scene2, Scene3} from './scenes1';
import {Scene4, Scene5, Scene6} from './scenes2';

/** Taruh file voice over di public/vo/ lalu ubah ke true */
const VO_READY = false;
const VO = [
  {file: 'vo/s1.mp3', from: 15}, {file: 'vo/s2_ibu.mp3', from: 330}, {file: 'vo/s2_riko.mp3', from: 420},
  {file: 'vo/s3_bapak.mp3', from: 630}, {file: 'vo/s4.mp3', from: 930}, {file: 'vo/s5.mp3', from: 1215}, {file: 'vo/s6.mp3', from: 1530},
];

const SUBS: Sub[] = [
  {from: 0.5, to: 4.5, text: 'Bekal sebulan dari orang tua...'},
  {from: 4.5, to: 9.5, text: 'gue habisin 2 hari gara-gara judol.'},
  {from: 11, to: 13.8, text: 'IBU: Cukup nak?'},
  {from: 14, to: 19.5, text: 'Cukup Bu... enak terus kok.'},
  {from: 21, to: 25, text: 'BAPAK: Bapak udah gak sanggup lagi nak...'},
  {from: 31, to: 36, text: 'Makan 3 hari... atau gue coba sekali lagi,'},
  {from: 36, to: 39.5, text: 'tapi bener?'},
  {from: 40.5, to: 43.5, text: 'Kali ini gue gak serakah.'},
  {from: 43.5, to: 47, text: 'Menang gue tarik separuh, buat makan.'},
  {from: 47, to: 50, text: 'Separuh lagi gue puter lagi.'},
  {from: 51, to: 56, text: 'Dari 50rb... akhirnya bisa bales budi.'},
];

const Wrap: React.FC<{children: React.ReactNode}> = ({children}) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [0, 8, 292, 300], [0, 1, 1, 0], clamp);
  const s = interpolate(f, [0, 12], [1.06, 1], clamp);
  return <AbsoluteFill style={{opacity: o, transform: `scale(${s})`}}>{children}</AbsoluteFill>;
};

const SCENES = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6];

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    <Audio src={staticFile('backsound.wav')} volume={0.9} />
    {VO_READY && VO.map((v) => <Sequence key={v.file} from={v.from}><Audio src={staticFile(v.file)} /></Sequence>)}
    {SCENES.map((S, i) => (
      <Sequence key={i} from={i * 300} durationInFrames={300}><Wrap><S /></Wrap></Sequence>
    ))}
    <FilmOverlay />
    <Subtitles subs={SUBS} />
  </AbsoluteFill>
);
