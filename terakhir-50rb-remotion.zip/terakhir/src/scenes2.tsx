import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FONT, H, Handheld, KosRoom, Kinetic, Particles, Phone, W, clamp, rp} from './common';
import {Dani, Ibu, Riko} from './characters';

/* ===== SCENE 4 — DILEMA ALL IN ===== */
export const Scene4: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const daniX = interpolate(f, [0, 50], [-600, 10], {...clamp, easing: Easing.out(Easing.cubic)});
  const b1 = spring({frame: f - 100, fps, config: {damping: 12}});
  const b2 = spring({frame: f - 115, fps, config: {damping: 12}});
  const eyes = spring({frame: f - 150, fps, config: {damping: 14}}) * (f < 214 ? 1 : 0);
  const t = interpolate(f, [214, 262], [0, 1], {...clamp, easing: Easing.inOut(Easing.quint)});
  const cx = interpolate(t, [0, 1], [820, 540]), cy = interpolate(t, [0, 1], [1300, 640]);
  const press = interpolate(f, [258, 266, 280], [1, 0.9, 1], clamp);
  const flash = interpolate(f, [262, 268, 295], [0, 1, 0], clamp);
  const ring = f - 262;
  const flick = 0.85 + 0.15 * Math.sin(f * 1.3);
  const btn = (label: string, c: string, top: number, p: number, sc = 1) => (
    <div style={{position: 'absolute', left: 140, top, width: 800, height: 190, borderRadius: 30, border: `4px solid ${c}`, background: `${c}22`,
      boxShadow: `0 0 50px ${c}, inset 0 0 40px ${c}55`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FONT,
      fontSize: 62, color: '#fff', opacity: p * flick, transform: `scale(${(0.6 + 0.4 * p) * sc})`}}>[ {label} ]</div>
  );
  return (
    <AbsoluteFill>
      <Handheld amount={7}>
        <KosRoom bright={0.45} />
        <div style={{position: 'absolute', left: daniX, top: 800}}><Dani scale={1.3} /></div>
        <div style={{position: 'absolute', left: 70, top: 700, width: 300, height: 200, borderRadius: 20, background: '#0c1a14', border: '4px solid #2a4', opacity: interpolate(f, [60, 80], [0, 1], clamp)}}>
          <svg width="300" height="200" viewBox="0 0 300 200"><polyline fill="none" stroke="#3ddc84" strokeWidth="5" points="10,150 50,120 90,140 130,90 170,110 210,60 250,80 290,40" /></svg>
        </div>
        <div style={{position: 'absolute', left: 440, top: 930}}><Riko expr={f < 214 ? 'sweat' : 'focus'} scale={1.4} /></div>
        {btn('BELI MAKAN 3 HARI', '#00e5ff', 330, b1)}
        {btn('ALL IN TRADING', '#ff2d95', 570, b2, press)}
        <Particles count={30} color="0,229,255" speed={0.9} seed="holo" size={6} />
        {eyes > 0.01 && (
          <div style={{position: 'absolute', left: 90, top: 1150, width: 900, height: 280, overflow: 'hidden', borderRadius: 24, border: '6px solid #fff',
            transform: `scale(${eyes})`, background: '#c9936a', boxShadow: '0 0 60px rgba(0,0,0,.8)'}}>
            <div style={{position: 'absolute', left: -150, top: -595}}><Riko expr="sweat" scale={3} /></div>
          </div>
        )}
        {f > 214 && (
          <div style={{position: 'absolute', left: cx - 45, top: cy - 45, width: 90, height: 90, borderRadius: '50%', border: '6px solid #fff', background: 'rgba(255,255,255,.25)',
            transform: `translate(${Math.sin(f * 2) * 4}px,${Math.cos(f * 2.3) * 4}px)`}} />
        )}
        {ring > 0 && [0, 12, 24].map((d) => {
          const r = Math.max(0, ring - d);
          return <div key={d} style={{position: 'absolute', left: 540 - r * 9, top: 665 - r * 9, width: r * 18, height: r * 18, borderRadius: '50%', border: '5px solid #ff2d95', opacity: Math.max(0, 1 - r / 40)}} />;
        })}
      </Handheld>
      <Kinetic text="DILEMA" delay={0} size={110} color="#ff4d6d" top={110} />
      <AbsoluteFill style={{background: '#fff', opacity: flash * 0.9}} />
    </AbsoluteFill>
  );
};

/* ===== SCENE 5 — PROSES DISIPLIN, GRAFIK NAIK ===== */
export const Scene5: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pts = [50, 54, 58, 62, 66, 71];
  const X0 = 40, X1 = 880, Y0 = 520, Y1 = 60;
  const path = pts.map((v, i) => `${i ? 'L' : 'M'}${X0 + (i / (pts.length - 1)) * (X1 - X0)} ${Y0 - ((v - 45) / 30) * (Y0 - Y1)}`).join(' ');
  const prog = interpolate(f, [10, 120], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const val = interpolate(f, [10, 45, 80, 105], [50000, 58000, 58000, 71000], {...clamp, easing: Easing.out(Easing.cubic)});
  const card = (i: number) => spring({frame: f - [40, 110][i], fps, config: {damping: 13}});
  const c1o = interpolate(f, [100, 112], [1, 0], clamp);
  const write = interpolate(f, [150, 250], [0, 1], clamp);
  const bright = interpolate(f, [0, 300], [0.2, 0.9], clamp);
  return (
    <AbsoluteFill>
      <Handheld amount={4}>
        <KosRoom bright={bright} clockFast={14} tidy={f > 150} />
        <Particles count={26} color="255,230,150" speed={1.5} seed="s5" size={7} />
        <div style={{position: 'absolute', left: 60, top: 300, width: 960, height: 640, borderRadius: 36, background: 'rgba(8,16,14,.82)', border: '3px solid #3ddc84', boxShadow: '0 0 70px rgba(61,220,132,.35)', padding: 40}}>
          <div style={{fontFamily: FONT, color: '#3ddc84', fontSize: 38}}>SALDO TRADING</div>
          <div style={{fontFamily: FONT, color: '#fff', fontSize: 92}}>{rp(val)}</div>
          <svg width="900" height="560" viewBox="0 0 900 560" style={{position: 'absolute', left: 40, top: 130}}>
            <path d={path} pathLength={1} fill="none" stroke="#3ddc84" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="1" strokeDashoffset={1 - prog} style={{filter: 'drop-shadow(0 0 14px #3ddc84)'}} />
          </svg>
        </div>
        <div style={{position: 'absolute', left: 90, top: 970, width: 900, height: 150}}>
          {[['HARI 1  •  Rp 58.000', 'tarik 4rb buat warteg'], ['HARI 2  •  Rp 71.000', 'tarik buat token listrik']].map(([a, b], i) => {
            const p = card(i) * (i === 0 ? c1o : 1);
            return (
              <div key={i} style={{position: 'absolute', inset: 0, borderRadius: 28, background: '#fff', padding: '24px 34px', fontFamily: FONT, opacity: p, transform: `translateY(${(1 - p) * 80}px) rotate(${i ? 1.5 : -1.5}deg)`}}>
                <div style={{fontSize: 48, color: '#0a7a3d'}}>{a}</div>
                <div style={{fontSize: 34, color: '#333'}}>{b}</div>
              </div>
            );
          })}
        </div>
        <div style={{position: 'absolute', left: 50, top: 1170, width: 640, height: 300, background: '#f5ecd0', borderRadius: 10, transform: 'rotate(-3deg)', boxShadow: '0 20px 50px rgba(0,0,0,.6)',
          backgroundImage: 'repeating-linear-gradient(transparent 0 58px,#9bb 58px 60px)', opacity: interpolate(f, [140, 155], [0, 1], clamp)}}>
          <div style={{position: 'absolute', left: 24, top: 20, width: 600 * write, overflow: 'hidden', whiteSpace: 'nowrap', fontFamily: "'Caveat','Comic Sans MS',cursive", fontSize: 62, color: '#1b2a6b', lineHeight: '62px'}}>
            ATURAN:<br />MENANG TARIK<br />SEPARUH
          </div>
        </div>
        <div style={{position: 'absolute', left: 650, top: 1100}}><Riko expr={f < 200 ? 'focus' : 'happy'} scale={0.95} /></div>
      </Handheld>
    </AbsoluteFill>
  );
};

/* ===== SCENE 6 — HAPPY ENDING + ENDING FRAME ===== */
export const Scene6: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const recv = spring({frame: f - 70, fps, config: {damping: 14}});
  const chk = interpolate(f, [100, 130], [1, 0], clamp);
  const sun = interpolate(f, [0, 200], [0, 0.45], clamp);
  const black = interpolate(f, [205, 235], [0, 1], clamp);
  const pulse = 1 + 0.05 * Math.sin(f * 0.25);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Handheld amount={4}>
        <KosRoom tidy bright={0.95} />
        <AbsoluteFill style={{background: 'linear-gradient(rgba(255,140,40,.9),rgba(255,90,20,0))', opacity: sun, mixBlendMode: 'soft-light'}} />
        <Particles count={40} color="255,200,110" speed={1.0} seed="s6" size={8} />
        <div style={{position: 'absolute', left: 260, top: 190}}>
          <Phone w={560} h={640}>
            <div style={{height: '100%', background: 'linear-gradient(#6b4a2a,#3d2a17)', textAlign: 'center'}}>
              <div style={{marginTop: 60}}><Ibu mood="joy" scale={0.95} /></div>
            </div>
          </Phone>
        </div>
        <div style={{position: 'absolute', left: 90, top: 880, width: 900, height: 430, borderRadius: 36, background: '#fff', overflow: 'hidden', fontFamily: FONT,
          transform: `translateY(${(1 - recv) * 900}px)`, boxShadow: '0 30px 80px rgba(0,0,0,.6)'}}>
          <div style={{background: '#0a56b8', color: '#fff', padding: '26px 40px', fontSize: 42}}>BRI  •  TRANSFER BERHASIL</div>
          <div style={{padding: '28px 40px', color: '#222'}}>
            <div style={{fontSize: 34, opacity: 0.6}}>Ke: Ibu (Kampung)</div>
            <div style={{fontSize: 108, color: '#0a56b8'}}>Rp 1.000.000</div>
          </div>
          <svg width="110" height="110" viewBox="0 0 110 110" style={{position: 'absolute', right: 40, top: 160}}>
            <circle cx="55" cy="55" r="48" fill="#1fb35a" />
            <path d="M30 56 L48 74 L82 36" pathLength={1} fill="none" stroke="#fff" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="1" strokeDashoffset={chk} />
          </svg>
        </div>
        <div style={{position: 'absolute', left: 30, top: 1320}}><Riko expr="happy" scale={1.0} /></div>
      </Handheld>
      <AbsoluteFill style={{background: '#000', opacity: black}} />
      {f > 215 && (
        <AbsoluteFill>
          <Kinetic text="Dari 50rb sisa celengan." delay={225} size={76} top={560} glitch={false} />
          <Kinetic text="Stop Judol, Mulai Belajar." delay={250} size={88} color="#ffd24a" top={800} glitch={false} />
          <div style={{position: 'absolute', left: 190, top: 1150, width: 700, height: 150, borderRadius: 75, background: 'linear-gradient(#2ee06f,#119a45)', color: '#fff', fontFamily: FONT,
            fontSize: 52, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 60px rgba(46,224,111,.6)',
            opacity: interpolate(f, [262, 275], [0, 1], clamp), transform: `scale(${pulse})`}}>⬇  DOWNLOAD MP4</div>
          <div style={{position: 'absolute', left: 80, right: 80, bottom: 120, textAlign: 'center', fontFamily: 'system-ui,sans-serif', fontSize: 30, color: '#9a9a9a', opacity: interpolate(f, [260, 280], [0, 1], clamp)}}>
            Cerita ilustrasi. Trading berisiko tinggi, bisa rugi total. Bukan ajakan & bukan jaminan untung.
          </div>
        </AbsoluteFill>
      )}
    </AbsoluteFill>
  );
};
